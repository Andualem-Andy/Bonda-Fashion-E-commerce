import React, { Component } from "react";

export default class Women extends Component {
  render() {
    return <div>Women</div>;
  }
}
