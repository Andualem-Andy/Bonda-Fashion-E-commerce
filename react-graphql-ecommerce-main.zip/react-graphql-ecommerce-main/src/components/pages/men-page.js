import React, { Component } from "react";

export default class Men extends Component {
  render() {
    return <div>Men</div>;
  }
}
