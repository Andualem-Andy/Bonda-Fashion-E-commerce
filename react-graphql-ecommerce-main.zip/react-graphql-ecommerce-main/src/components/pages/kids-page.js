import React, { Component } from "react";

export default class Kids extends Component {
  render() {
    return <div>Kids</div>;
  }
}
