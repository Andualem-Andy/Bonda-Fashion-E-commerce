import MainRoutes from "./Routes";
import "./App.css";

function App() {
  return <MainRoutes />;
}

export default App;
