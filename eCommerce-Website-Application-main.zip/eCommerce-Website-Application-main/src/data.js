export const sliderItems = [
    {
        id: 1,
        img: "https://i.ibb.co/Z1Tg7Wg/Yellow-female-fashion-accessories-shoes-and-handbag-over-orange-background-Beauty-shopping-urban-out.jpg",
        title: "BLACK FRIDAY",
        desc: "DON'T COMPROMISE ON STYLE! GET FLAT 30% OFF FOR NEW ARRIVALS",
        bg: "f5fafd"
    },
    {
        id: 2,
        img: "https://i.ibb.co/R0WpnjZ/Adobe-Stock-296961342.jpg",
        title: "CELEBRITYWEAR",
        desc: "DON'T COMPROMISE ON STYLE! GET FLAT 30% OFF FOR NEW ARRIVALS",
        bg: "fcf1ed"
    },
    {
        id: 3,
        img: "https://i.ibb.co/4T50H7P/Beautiful-African-American-woman-with-pineapple-near-color-wall.jpg",
        title: "LOUNGEWEAR LOVE",
        desc: "DON'T COMPROMISE ON STYLE! GET FLAT 30% OFF FOR NEW ARRIVALS",
        bg: "fbf0f4"
    }
];

export const categories = [
    {
        id: 1,
        img: "https://i.ibb.co/HnmB3GW/shirt.jpg",
        title: "SHIRT STYLE",
        cat: "women"
    },
    {
        id: 2,
        img: "https://i.ibb.co/DwfP6k1/tshirt.jpg",
        title: "LOUNGEWEAR LOVE",
        cat: "coat"
    },
    {
        id: 3,
        img: "https://i.ibb.co/gFsm0KY/Jacket.jpg",
        title: "LIGHT JACKETS",
        cat: "jeans"
    }
];

export const popularProducts = [
    {
        id: 1,
        img: "https://i.ibb.co/gFsm0KY/Jacket.jpg"
    },
    {
        id: 2,
        img: "https://i.ibb.co/gFsm0KY/Jacket.jpg"
    },
    {
        id: 3,
        img: "https://i.ibb.co/gFsm0KY/Jacket.jpg"
    },
    {
        id: 4,
        img: "https://i.ibb.co/gFsm0KY/Jacket.jpg"
    },
    {
        id: 5,
        img: "https://i.ibb.co/gFsm0KY/Jacket.jpg"
    },
    {
        id: 6,
        img: "https://i.ibb.co/gFsm0KY/Jacket.jpg"
    },
    {
        id: 7,
        img: "https://i.ibb.co/gFsm0KY/Jacket.jpg"
    },
    {
        id: 8,
        img: "https://i.ibb.co/gFsm0KY/Jacket.jpg"
    },
]
